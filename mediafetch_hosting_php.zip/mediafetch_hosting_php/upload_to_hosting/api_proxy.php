<?php
/**
 * MediaFetch Pro - PHP Proxy cho Shared Hosting (HTML/PHP)
 * Chuyển tiếp yêu cầu render sang Backend Server (Docker/VPS) và trả về file tải trực tiếp.
 */

// 1. Thay URL bên dưới bằng địa chỉ Backend của bạn (Render / Railway / VPS)
$BACKEND_URL = 'https://YOUR-BACKEND-URL.onrender.com/api/render';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

set_time_limit(300);
$rawBody = file_get_contents('php://input');

$ch = curl_init($BACKEND_URL);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $rawBody);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 290);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$curlErr = curl_error($ch);
curl_close($ch);

if ($curlErr) {
    http_response_code(502);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Backend unreachable: ' . $curlErr]);
    exit;
}

http_response_code($httpCode ?: 200);
if ($contentType) {
    header('Content-Type: ' . $contentType);
}
echo $response;
